## 1. Daily Bingo Hunt (DBH) Progression Revamp

## 2. Problem statements
- The current Daily Bingo Hunt (DBH) progression is unclear, causing players to be uncertain about their daily progress and what they are working towards.
- Transitions between puzzles are jarring, often pulling players out of the experience with unnecessary outro screens, which reduces engagement.
- The visual design language is inconsistent, with too many color variations causing confusion and a lack of clear visual hierarchy.
- There is no reward or incentive for completing the daily set of puzzles, leading to lower completion rates and session length.

## 3. Vision and anti-vision
<b>Vision</b>
- To create a clear, visually intuitive, and rewarding 5-tier progression system for the Daily Bingo Hunt.
- To keep players engaged within the game mode by providing seamless transitions between puzzles.
- To reward daily completion by unlocking a compelling 'unlimited' play mode, extending engagement and providing a clear daily goal.

<b>Anti-vision</b>
- A system that feels disjointed or pulls the player out of the game with unnecessary screens.
- A visually confusing interface with an overwhelming number of colors or states.
- A progression that feels unrewarding or where the final unlock is not compelling enough to encourage completion.
- A system where players feel their daily progress is lost or not clearly communicated upon returning.

## 4. Business and Design Goals
<b>Business Goals</b>
- Increase player engagement and session length within the Daily Bingo Hunt mode.
- Drive ad revenue through a "Watch to play" mechanic for the unlocked unlimited gameplay mode.
- Improve day-over-day retention for players who engage with DBH.

<b>Design Goals</b>
- Clearly communicate the player's daily progress through a simple, 5-tier visual system.
- Maintain player immersion by eliminating interruptions between puzzle completions.
- Provide a satisfying sense of completion and reward by unlocking a new mode of play.
- Establish a consistent and clean visual language that reduces cognitive load.
- Ensure the player's achieved state is persistent and visible across sessions to reinforce their accomplishment.

## 5. Opportunities
- To create a more compelling and sticky core loop for the Daily Bingo Hunt by adding a clear, achievable daily goal (unlocking unlimited play).
- To streamline the user flow between the curated daily puzzles and an extended gameplay session, thereby increasing time spent in the mode.
- To simplify the visual feedback system to improve usability and player understanding at a glance.

## 6. Expected Upsides
- Increase in the completion rate of the 5-puzzle daily set.
- Increase in average session length for players engaging with DBH.
- New revenue stream from ad impressions via the "Watch to play" gate for unlimited mode.
- Improved retention for the DBH game mode.

## 7. Overview
- This feature revamps the Daily Bingo Hunt (DBH) progression into a 5-tier system.
- Players complete a curated list of five puzzles each day to progress through the tiers.
- A new UI element, a set of five orbs, will visually track the player's progress. Each completed puzzle fills an orb with a specific color.
- The progression is seamless; there are no outro screens between completing puzzles 1 through 4.
- Upon completing the fifth and final puzzle, the progress bar turns golden, a "Congratulations" message is displayed, and the board transitions via a swipe animation to an "Unlimited DBH" mode.
- This unlimited mode allows players to continue playing DBH puzzles for the rest of the day by opting to watch a rewarded ad ("Watch to play").
- The player's highest achieved state (e.g., the golden state) persists and is visible on subsequent days to provide a sense of lasting accomplishment.

## 8. DBH Game Board UI
Header: DAILY BINGO HUNT
Sub text: WORD X OF 5
CTA: N/A
CTA functionality: N/A
Surfacing conditions:
- Visible during any of the five daily curated DBH puzzles.
UI Components:
- A progress bar with five circular orbs is displayed at the top of the screen.
- <b>Tier 1-4 (In-Progress)</b>: Orbs corresponding to completed puzzles are filled with a distinct color. The current puzzle's orb is highlighted.
- <b>Tier 5 (Final Puzzle)</b>: The first four orbs are filled. The progress bar turns from green to a golden color to signify the final stage.
- <b>Tier 5 (Complete)</b>: All five orbs are filled, and the entire progress bar maintains its golden state.
- The state is persistent. If a player leaves and returns on the same day, their progress is saved and displayed.
- The previous day's completed golden state remains visible (e.g., as a small icon or background treatment) on the next day to show accomplishment.
Mockup: [![Mockup](https://figma-alpha-api.s3.us-west-2.amazonaws.com/images/7e293ffd-34dd-42cf-8e6c-9d561d9e6df0)](https://www.figma.com/design/H3ABY5Ctu3uE9WALYOiaVs?node-id=479%3A139977)

## 9. Final Tier Completion Flow
Description:
- <b>Step 1</b>: Player successfully solves the 5th and final puzzle of the Daily Bingo Hunt.
- <b>Step 2</b>: The 5th orb in the progress bar fills, and the entire bar celebrates its golden state with a brief animation.
- <b>Step 3</b>: A non-blocking "Congratulations! You've reached the final tier of the day!" message appears briefly on screen and then fades.
- <b>Step 4</b>: The game board performs a quick, clean swipe animation (similar to an opponent's move transition) to reveal the unlimited DBH board.
- <b>Step 5</b>: The text "WORD 5 OF 5" is removed.
- <b>Step 6</b>: A "Watch to play" button appears, prompting the player to watch a rewarded ad to continue playing.
- <b>Step 7</b>: After watching an ad, a new, non-curated DBH puzzle is loaded for the player to solve. This can be repeated.
Mockup: [![Mockup](https://figma-alpha-api.s3.us-west-2.amazonaws.com/images/880eab31-f394-4499-8104-623805b70b5b)](https://www.figma.com/design/H3ABY5Ctu3uE9WALYOiaVs?node-id=929%3A250362)

## 10. Edge Cases
- <b>Player Fails a Puzzle</b>: If a player fails a puzzle, they can retry. The progress orb for that tier will not be marked as complete until the puzzle is successfully solved.
- <b>App Quit Mid-Puzzle</b>: The game state is saved. Upon returning, the player resumes the puzzle they were on.
- <b>App Quit Between Puzzles</b>: The completed tier is saved. Upon returning, the player is presented with the next puzzle in the sequence.
- <b>Next Day Rollover</b>: The 5-tier progress resets for the new day's puzzles. The golden achievement from the previous day remains visible as a persistent reward emblem. If the player did not complete all 5 tiers, the emblem is not awarded for the previous day.
- <b>No Ad Inventory</b>: If the player clicks "Watch to play" and no ad is available, display a toaster message: "No ads available right now. Please try again later." The button remains active for retries.
- <b>Bonus Puzzle Unlock</b>: When bonus puzzles are unlocked after tier completion, a notification or UI element should appear, but its final implementation is pending design. (Note for PM: Details to be filled in).

## 11. UI dev requirement
- Create a 5-orb progress bar component with the following states: default, in-progress, completed, and final (golden).
- Implement fill animations for each orb upon tier completion.
- Implement a color-changing animation for the progress bar background when the player reaches the 5th tier.
- Develop a seamless swipe transition animation between the final curated puzzle board and the unlimited mode board.
- Implement the "Watch to play" button and its associated ad-serving logic.
- Ensure the state of the progress bar and the unlocked status of the unlimited mode persists throughout the day and across app sessions.
- Create a persistent visual element to display the previous day's golden completion status.
- Color palette must be limited to a maximum of five distinct colors for the orbs to avoid visual confusion, plus the golden state.

## 12. Sound requirement
- A subtle, satisfying sound effect for completing each of the first four tiers.
- A more celebratory, rewarding sound jingle for completing the fifth and final tier.
- A smooth whoosh sound to accompany the swipe transition to the unlimited mode board.
- A standard UI click sound for the "Watch to play" button.

## 13. Experimentation Plan
- <b>Experiment name</b>: dbh_progression_revamp
- <b>Control</b>: 50% - Players see the existing Daily Bingo Hunt flow.
- <b>Var1</b>: 50% - Players experience the new 5-tier progression system with seamless transitions and the unlockable unlimited mode.

## 14. Tracking requirement
- A detailed tracking plan will be provided in a separate document.
- Key events to track:
- - `dbh_tier_complete`: Fired on completion of each puzzle. Parameters: `tier_number` (1-5).
- - `dbh_final_tier_complete`: Fired when the 5th puzzle is solved.
- - `dbh_unlimited_mode_unlocked`: Fired once per day when the unlimited mode is unlocked for the first time.
- - `dbh_watch_to_play_click`: Fired when the "Watch to play" button is tapped.
- - `dbh_unlimited_puzzle_start`: Fired each time a new puzzle is started in unlimited mode.
- - `dbh_puzzle_retry`: Fired when a player retries a puzzle.

## 15. Analysis Plan
- Compare the completion rate of the 5-puzzle daily set between Control and Var1.
- Measure the average number of puzzles played per user per day in DBH for both groups.
- Analyze the click-through rate and conversion (ad watch completion) of the "Watch to play" CTA in Var1.
- Monitor the impact on overall session length and daily retention for players who engage with the DBH mode.
- Review player feedback for comments on visual clarity and engagement.
- Note for PM: Details on Bonus Puzzle tracking will be added once unlock mechanics are finalized.

## 16. Changelog
- <b>v1.0 (Current)</b>: Initial specification drafted based on design notes and requirements. Awaiting final naming conventions for Bonus Puzzles and finalized unlock mechanics.